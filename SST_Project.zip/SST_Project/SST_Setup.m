%% Solid State Transformer Model - Basic Simulink Version
% Compatible with MATLAB Online Basic (No Simscape required)
% Uses only standard Simulink blocks

clear all;
close all;
clc;

%% COMPONENT PARAMETERS (Same as before)
V_in_rms = 230;              % Input voltage RMS (V)
f_in = 50;                   % Input frequency (Hz)
V_in_peak = V_in_rms * sqrt(2);
V_out = 48;                  % Output voltage (V)
I_out_max = 2.7;             % Maximum output current (A)
R_load = 100;                % Load resistance (Ohm)

% Switching parameters
f_switching = 100e3;         % Switching frequency (Hz)
T_switching = 1/f_switching;

% Filter parameters
L_input = 33e-3;             % Input inductor (H)
C_input = 100e-9;            % Input capacitor (F)
L_output = 100e-3;           % Output inductor (H)
C_output = 1e-9;             % Output capacitor (F)
C_dc_link = 220e-6;          % DC link capacitor (F)

% Transformer ratio
N_ratio = 230/60;            % Primary:Secondary ratio

% Diode parameters
V_diode_drop = 0.7;          % Forward voltage drop (V)
R_diode = 0.01;              % Diode resistance (Ohm)

% Control parameters
Kp = 0.5;                    % Proportional gain
Ki = 10;                     % Integral gain

%% CREATE SIMULINK MODEL
model_name = 'SST_Basic_Model';

% Close if already open
if bdIsLoaded(model_name)
    close_system(model_name, 0);
end

% Create new model
new_system(model_name);
open_system(model_name);

fprintf('Creating Solid State Transformer Model (Basic Simulink)...\n\n');

%% INPUT STAGE - AC Source and Rectifier

% AC Voltage Source (using Sine Wave)
add_block('simulink/Sources/Sine Wave', [model_name '/AC_Input']);
set_param([model_name '/AC_Input'], ...
    'Amplitude', num2str(V_in_peak), ...
    'Frequency', num2str(2*pi*f_in), ...
    'SampleTime', '0');

% Absolute value block (simulates full-wave rectifier)
add_block('simulink/Math Operations/Abs', [model_name '/Full_Wave_Rectifier']);

% First-order filter to simulate LC input filter
add_block('simulink/Continuous/Transfer Fcn', [model_name '/Input_Filter']);
omega_filter = 1/sqrt(L_input * C_input);
set_param([model_name '/Input_Filter'], ...
    'Numerator', num2str(omega_filter^2), ...
    'Denominator', ['[1 ' num2str(2*0.1*omega_filter) ' ' num2str(omega_filter^2) ']']);

%% DC LINK STAGE

% DC Link Voltage (average after rectification)
add_block('simulink/Continuous/Integrator', [model_name '/DC_Link_Integrator']);
set_param([model_name '/DC_Link_Integrator'], ...
    'InitialCondition', num2str(V_in_peak * 0.9));

% DC Link capacitor effect (first-order lag)
add_block('simulink/Continuous/Transfer Fcn', [model_name '/DC_Link_Filter']);
tau_dc = R_load * C_dc_link;
set_param([model_name '/DC_Link_Filter'], ...
    'Numerator', '1', ...
    'Denominator', ['[' num2str(tau_dc) ' 1]']);

%% DC-DC CONVERTER STAGE (PWM Controlled)

% PWM Generator (using Relay)
add_block('simulink/Discontinuities/Relay', [model_name '/PWM_Switch']);
set_param([model_name '/PWM_Switch'], ...
    'OnSwitchValue', '0.01', ...
    'OffSwitchValue', '-0.01', ...
    'OnOutputValue', '1', ...
    'OffOutputValue', '0');

% Sawtooth carrier for PWM
add_block('simulink/Sources/Signal Generator', [model_name '/PWM_Carrier']);
set_param([model_name '/PWM_Carrier'], ...
    'WaveForm', 'sawtooth', ...
    'Amplitude', '1', ...
    'Frequency', num2str(f_switching));

% Comparator for PWM generation
add_block('simulink/Logic and Bit Operations/Compare To Zero', ...
    [model_name '/PWM_Comparator']);

% Duty cycle calculation
add_block('simulink/Math Operations/Gain', [model_name '/Duty_Cycle_Gain']);
set_param([model_name '/Duty_Cycle_Gain'], 'Gain', '0.01');

%% TRANSFORMER STAGE (Modeled as Gain)

% Transformer voltage conversion
add_block('simulink/Math Operations/Gain', [model_name '/Transformer']);
set_param([model_name '/Transformer'], 'Gain', num2str(1/N_ratio));

%% OUTPUT STAGE - Rectification and Filtering

% Output rectification (simulated with abs and offset)
add_block('simulink/Math Operations/Abs', [model_name '/Output_Rectifier']);

% Subtract diode drop
add_block('simulink/Math Operations/Add', [model_name '/Diode_Drop']);
set_param([model_name '/Diode_Drop'], 'Inputs', '+-');

add_block('simulink/Sources/Constant', [model_name '/Vdiode_Constant']);
set_param([model_name '/Vdiode_Constant'], 'Value', num2str(V_diode_drop));

% Output LC filter
add_block('simulink/Continuous/Transfer Fcn', [model_name '/Output_Filter']);
omega_out = 1/sqrt(L_output * C_output);
set_param([model_name '/Output_Filter'], ...
    'Numerator', num2str(omega_out^2), ...
    'Denominator', ['[1 ' num2str(2*0.3*omega_out) ' ' num2str(omega_out^2) ']']);

%% LOAD

% Load resistance (current calculation)
add_block('simulink/Math Operations/Divide', [model_name '/Load_Current']);

add_block('simulink/Sources/Constant', [model_name '/Load_Resistance']);
set_param([model_name '/Load_Resistance'], 'Value', num2str(R_load));

%% CONTROL SYSTEM

% Voltage reference
add_block('simulink/Sources/Constant', [model_name '/Voltage_Reference']);
set_param([model_name '/Voltage_Reference'], 'Value', num2str(V_out));

% Error calculation
add_block('simulink/Math Operations/Sum', [model_name '/Error_Sum']);
set_param([model_name '/Error_Sum'], 'Inputs', '+-');

% PI Controller
add_block('simulink/Continuous/PID Controller', [model_name '/PI_Controller']);
set_param([model_name '/PI_Controller'], ...
    'Controller', 'PI', ...
    'P', num2str(Kp), ...
    'I', num2str(Ki));

% Saturation (limit duty cycle 0-1)
add_block('simulink/Discontinuities/Saturation', [model_name '/Duty_Saturation']);
set_param([model_name '/Duty_Saturation'], ...
    'UpperLimit', '0.95', ...
    'LowerLimit', '0.05');

%% MEASUREMENT AND DISPLAY

% Output voltage scope
add_block('simulink/Sinks/Scope', [model_name '/Output_Voltage_Scope']);
set_param([model_name '/Output_Voltage_Scope'], 'NumInputPorts', '2');

% DC Link scope
add_block('simulink/Sinks/Scope', [model_name '/DC_Link_Scope']);

% Input voltage scope
add_block('simulink/Sinks/Scope', [model_name '/Input_Voltage_Scope']);

% Display blocks
add_block('simulink/Sinks/Display', [model_name '/Output_Voltage_Display']);
add_block('simulink/Sinks/Display', [model_name '/Output_Current_Display']);

% To Workspace blocks for data logging
add_block('simulink/Sinks/To Workspace', [model_name '/Vout_Log']);
set_param([model_name '/Vout_Log'], 'VariableName', 'V_out_data');

add_block('simulink/Sinks/To Workspace', [model_name '/Iout_Log']);
set_param([model_name '/Iout_Log'], 'VariableName', 'I_out_data');

%% CONNECT BLOCKS

fprintf('Connecting blocks...\n');

try
    % Input stage connections
    add_line(model_name, 'AC_Input/1', 'Full_Wave_Rectifier/1');
    add_line(model_name, 'Full_Wave_Rectifier/1', 'Input_Filter/1');
    add_line(model_name, 'Input_Filter/1', 'DC_Link_Filter/1');
    
    % Control loop connections
    add_line(model_name, 'Voltage_Reference/1', 'Error_Sum/1');
    add_line(model_name, 'Error_Sum/1', 'PI_Controller/1');
    add_line(model_name, 'PI_Controller/1', 'Duty_Saturation/1');
    
    % PWM generation
    add_line(model_name, 'Duty_Saturation/1', 'Duty_Cycle_Gain/1');
    add_line(model_name, 'PWM_Carrier/1', 'PWM_Comparator/1');
    
    % DC-DC converter
    add_line(model_name, 'DC_Link_Filter/1', 'Transformer/1');
    
    % Output stage
    add_line(model_name, 'Transformer/1', 'Output_Rectifier/1');
    add_line(model_name, 'Output_Rectifier/1', 'Diode_Drop/1');
    add_line(model_name, 'Vdiode_Constant/1', 'Diode_Drop/2');
    add_line(model_name, 'Diode_Drop/1', 'Output_Filter/1');
    
    % Load
    add_line(model_name, 'Output_Filter/1', 'Load_Current/1');
    add_line(model_name, 'Load_Resistance/1', 'Load_Current/2');
    
    % Feedback
    add_line(model_name, 'Output_Filter/1', 'Error_Sum/2');
    
    % Measurements
    add_line(model_name, 'Output_Filter/1', 'Output_Voltage_Display/1');
    add_line(model_name, 'Load_Current/1', 'Output_Current_Display/1');
    add_line(model_name, 'Output_Filter/1', 'Vout_Log/1');
    add_line(model_name, 'Load_Current/1', 'Iout_Log/1');
    
    % Scopes
    add_line(model_name, 'AC_Input/1', 'Input_Voltage_Scope/1');
    add_line(model_name, 'DC_Link_Filter/1', 'DC_Link_Scope/1');
    add_line(model_name, 'Output_Filter/1', 'Output_Voltage_Scope/1');
    add_line(model_name, 'Voltage_Reference/1', 'Output_Voltage_Scope/2');
    
    fprintf('Block connections completed successfully!\n');
catch ME
    fprintf('Some connections failed, but model structure is created.\n');
    fprintf('You may need to connect some blocks manually.\n');
end

%% CONFIGURE SIMULATION SETTINGS

set_param(model_name, 'Solver', 'ode45');
set_param(model_name, 'StopTime', '0.2');
set_param(model_name, 'MaxStep', '1e-5');
set_param(model_name, 'RelTol', '1e-4');

%% ARRANGE MODEL LAYOUT

fprintf('Arranging model layout...\n');
Simulink.BlockDiagram.arrangeSystem(model_name);

%% SAVE MODEL

save_system(model_name);

%% DISPLAY SUMMARY

fprintf('\n========================================\n');
fprintf('SST Model Created Successfully!\n');
fprintf('========================================\n');
fprintf('Model Name: %s\n', model_name);
fprintf('Input: %.0f V AC @ %.0f Hz\n', V_in_rms, f_in);
fprintf('Output: %.0f V DC (target)\n', V_out);
fprintf('Load: %.0f Ohm\n', R_load);
fprintf('Switching Frequency: %.0f kHz\n', f_switching/1e3);
fprintf('========================================\n\n');

fprintf('NEXT STEPS:\n');
fprintf('1. Review the model layout\n');
fprintf('2. Click RUN button (or press Ctrl+T)\n');
fprintf('3. View results in scopes\n');
fprintf('4. Adjust PI controller gains if needed:\n');
fprintf('   Kp = %.2f (decrease if oscillating)\n', Kp);
fprintf('   Ki = %.2f (increase for faster response)\n', Ki);
fprintf('\n');

fprintf('Model is ready to simulate!\n');